# mplink_to_google_sheets
 osu! мп линк парсер для загрузки результатов матчей в google spreadsheet. 
Credits to B0ound for the way to get mp results in a json
